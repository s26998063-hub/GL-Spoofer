package com.astrodir.a36goodlockspoofer;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.telephony.TelephonyManager;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String PKG_GOOD_LOCK = "com.samsung.android.goodlock";
    private static final String PKG_GALAXY_STORE = "com.sec.android.app.samsungapps";

    private static final String TARGET_MODEL = "SM-A366B";
    private static final String TARGET_DEVICE = "a36xq";
    private static final String TARGET_PRODUCT = "a36xqxx";
    private static final String TARGET_CSC = "EUX";
    private static final String TARGET_PRODUCT_CODE = "SM-A366BZKCEUX";
    private static final String TARGET_FINGERPRINT =
            "samsung/a36xqxx/a36xq:16/BP2A.250605.031.A3/A366BXXU1AYC1:user/release-keys";

    private static final String PREF_FLAG_FILE = "astrodir_spoofer_state";
    private static final String KEY_INITIAL_CLEAN_DONE = "initial_clean_done_v1";

    private static final Set<String> MODEL_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.model",
            "ro.product.vendor.model",
            "ro.product.system.model",
            "ro.product.system_ext.model",
            "ro.product.odm.model",
            "ro.product.product.model",
            "ro.product.bootimage.model",
            "ro.product.model_for_attestation",
            "ro.boot.em.model"
    ));

    private static final Set<String> DEVICE_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.device",
            "ro.product.vendor.device",
            "ro.product.system.device",
            "ro.product.system_ext.device",
            "ro.product.odm.device",
            "ro.product.product.device",
            "ro.product.bootimage.device",
            "ro.product.device_for_attestation"
    ));

    private static final Set<String> PRODUCT_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.name",
            "ro.product.vendor.name",
            "ro.product.system.name",
            "ro.product.system_ext.name",
            "ro.product.odm.name",
            "ro.product.product.name",
            "ro.product.bootimage.name",
            "ro.build.product",
            "ro.product.name_for_attestation"
    ));

    private static final Set<String> CSC_KEYS = new HashSet<>(Arrays.asList(
            "ro.csc.sales_code",
            "ril.sales_code",
            "persist.sys.csc.sales_code",
            "ril.matchedcsc",
            "ril.matchedcsc2",
            "persist.audio.sales_code"
    ));

    private static final Set<String> PRODUCT_CODE_KEYS = new HashSet<>(Arrays.asList(
            "ril.product_code",
            "ril.product_code2",
            "vendor.ril.product_code"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG_GOOD_LOCK.equals(lpparam.packageName) && !PKG_GALAXY_STORE.equals(lpparam.packageName)) {
            return;
        }

        spoofBuildFields();
        hookSystemProperties(lpparam.classLoader);
        hookFloatingFeature(lpparam.classLoader);
        hookTelephony(lpparam.classLoader);

        if (PKG_GOOD_LOCK.equals(lpparam.packageName)) {
            hookInitialCleanup(lpparam.classLoader);
        }
    }

    private void hookInitialCleanup(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    Application.class,
                    "attach",
                    Context.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Context baseContext = (Context) param.args[0];
                            if (baseContext == null) return;

                            SharedPreferences statePrefs = baseContext.getSharedPreferences(
                                    PREF_FLAG_FILE, Context.MODE_PRIVATE);
                            boolean alreadyCleaned = statePrefs.getBoolean(KEY_INITIAL_CLEAN_DONE, false);

                            if (!alreadyCleaned) {
                                performOneTimeCleanup(baseContext);
                                SharedPreferences freshPrefs = baseContext.getSharedPreferences(
                                        PREF_FLAG_FILE, Context.MODE_PRIVATE);
                                freshPrefs.edit().putBoolean(KEY_INITIAL_CLEAN_DONE, true).commit();
                                XposedBridge.log("[A36GoodLockSpoofer] One-time Good Lock data cleanup completed.");
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("[A36GoodLockSpoofer] hookInitialCleanup error: " + t.getMessage());
        }
    }

    private void performOneTimeCleanup(Context context) {
        try {
            File dataDir = context.getDataDir();
            if (dataDir == null || !dataDir.exists()) return;

            String[] targetFolders = new String[]{
                    "shared_prefs",
                    "databases",
                    "cache",
                    "code_cache",
                    "files",
                    "no_backup"
            };

            for (String folderName : targetFolders) {
                File dir = new File(dataDir, folderName);
                if (dir.exists()) {
                    deleteRecursive(dir);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log("[A36GoodLockSpoofer] performOneTimeCleanup error: " + t.getMessage());
        }
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        //noinspection ResultOfMethodCallIgnored
        fileOrDir.delete();
    }

    private void spoofBuildFields() {
        setStaticField(Build.class, "MODEL", TARGET_MODEL);
        setStaticField(Build.class, "DEVICE", TARGET_DEVICE);
        setStaticField(Build.class, "PRODUCT", TARGET_PRODUCT);
        setStaticField(Build.class, "BRAND", "samsung");
        setStaticField(Build.class, "MANUFACTURER", "samsung");
        setStaticField(Build.class, "FINGERPRINT", TARGET_FINGERPRINT);
    }

    private void setStaticField(Class<?> clazz, String fieldName, Object value) {
        try {
            Field field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(null, value);
        } catch (Throwable ignored) {
        }
    }

    private void hookSystemProperties(ClassLoader classLoader) {
        try {
            Class<?> sysProps = XposedHelpers.findClass("android.os.SystemProperties", classLoader);

            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String key = (String) param.args[0];
                    String spoofed = mapProperty(key);
                    if (spoofed != null) {
                        param.setResult(spoofed);
                    }
                }
            });

            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String key = (String) param.args[0];
                    String spoofed = mapProperty(key);
                    if (spoofed != null) {
                        param.setResult(spoofed);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("[A36GoodLockSpoofer] hookSystemProperties error: " + t.getMessage());
        }
    }

    private String mapProperty(String key) {
        if (key == null) return null;
        if (MODEL_KEYS.contains(key)) return TARGET_MODEL;
        if (DEVICE_KEYS.contains(key)) return TARGET_DEVICE;
        if (PRODUCT_KEYS.contains(key)) return TARGET_PRODUCT;
        if (CSC_KEYS.contains(key)) return TARGET_CSC;
        if (PRODUCT_CODE_KEYS.contains(key)) return TARGET_PRODUCT_CODE;
        if ("ro.build.characteristics".equals(key) || "ro.vendor.build.characteristics".equals(key)) {
            return "phone";
        }
        if ("ro.csc.country_code".equals(key)) return "GERMANY";
        if ("ro.csc.countryiso_code".equals(key)) return "DE";
        return null;
    }

    private void hookFloatingFeature(ClassLoader classLoader) {
        try {
            Class<?> semFF = XposedHelpers.findClassIfExists(
                    "com.samsung.android.feature.SemFloatingFeature", classLoader);
            if (semFF == null) return;

            XposedHelpers.findAndHookMethod(semFF, "getBoolean", String.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String tag = (String) param.args[0];
                    if (tag != null && (tag.contains("ONEUI_CORE") || tag.contains("SEP_LITE"))) {
                        param.setResult(false);
                    }
                }
            });

            XposedHelpers.findAndHookMethod(semFF, "getBoolean", String.class, boolean.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    String tag = (String) param.args[0];
                    if (tag != null && (tag.contains("ONEUI_CORE") || tag.contains("SEP_LITE"))) {
                        param.setResult(false);
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void hookTelephony(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getSimOperator", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("26201");
                }
            });
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getNetworkOperator", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("26201");
                }
            });
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getSimCountryIso", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("de");
                }
            });
        } catch (Throwable ignored) {
        }
    }
}
