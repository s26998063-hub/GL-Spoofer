package com.astrodir.a36goodlockspoofer;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.telephony.TelephonyManager;

import java.io.File;
import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collections;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String PKG_GOOD_LOCK = "com.samsung.android.goodlock";
    private static final String PKG_GALAXY_STORE = "com.sec.android.app.samsungapps";

    // TEST flags
    private static final boolean SPOOF_COUNTRY = true;  // country props + SIM/network operator (Germany)
    private static final boolean SPOOF_CSC = false;     // sales code EUX / product code

    private static final String TAG = "[A36GoodLockSpoofer]";
    private static final Set<String> LOGGED = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
    private static final Pattern INTERESTING = Pattern.compile(
            "model|csc|sales|oneui|sep|product|operator|country|build\\.version|characteristics|device|omc|region",
            Pattern.CASE_INSENSITIVE);

    private static void dlogOnce(String msg) {
        if (LOGGED.add(msg)) XposedBridge.log(TAG + " " + msg);
    }

    private static final String TARGET_MODEL = "SM-A366B";
    private static final String TARGET_DEVICE = "a36xq";
    private static final String TARGET_PRODUCT = "a36xqxx";
    private static final String TARGET_CSC = "EUX";
    private static final String TARGET_PRODUCT_CODE = "SM-A366BZKCEUX";
    private static final String TARGET_FINGERPRINT =
            "samsung/a36xqxx/a36xq:16/BP2A.250605.031.A3/A366BXXU1AYC1:user/release-keys";

    private static final String PREF_FLAG_FILE = "astrodir_spoofer_state";
    private static final String KEY_INITIAL_CLEAN_DONE = "initial_clean_done_v1";

    private static final Set<String> MODEL_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.model",
            "ro.product.vendor.model",
            "ro.product.system.model",
            "ro.product.system_ext.model",
            "ro.product.odm.model",
            "ro.product.product.model",
            "ro.product.bootimage.model",
            "ro.product.model_for_attestation",
            "ro.boot.em.model"
    ));

    private static final Set<String> DEVICE_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.device",
            "ro.product.vendor.device",
            "ro.product.system.device",
            "ro.product.system_ext.device",
            "ro.product.odm.device",
            "ro.product.product.device",
            "ro.product.bootimage.device",
            "ro.product.device_for_attestation"
    ));

    private static final Set<String> PRODUCT_KEYS = new HashSet<>(Arrays.asList(
            "ro.product.name",
            "ro.product.vendor.name",
            "ro.product.system.name",
            "ro.product.system_ext.name",
            "ro.product.odm.name",
            "ro.product.product.name",
            "ro.product.bootimage.name",
            "ro.build.product",
            "ro.product.name_for_attestation"
    ));

    private static final Set<String> CSC_KEYS = new HashSet<>(Arrays.asList(
            "ro.csc.sales_code",
            "ril.sales_code",
            "persist.sys.csc.sales_code",
            "ril.matchedcsc",
            "ril.matchedcsc2",
            "persist.audio.sales_code",
            "persist.omc.sales_code"
    ));

    private static final Set<String> PRODUCT_CODE_KEYS = new HashSet<>(Arrays.asList(
            "ril.product_code",
            "ril.product_code2",
            "vendor.ril.product_code"
    ));

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!PKG_GOOD_LOCK.equals(lpparam.packageName) && !PKG_GALAXY_STORE.equals(lpparam.packageName)) {
            return;
        }

        dlogOnce("LOADED pkg=" + lpparam.packageName + " process=" + lpparam.processName
                + " realModel(before)=" + Build.MODEL + " sdk=" + Build.VERSION.SDK_INT);
        spoofBuildFields();
        dlogOnce("Build.MODEL after spoof=" + Build.MODEL + " pkg=" + lpparam.packageName);
        hookSystemProperties(lpparam.classLoader);
        hookFloatingFeature(lpparam.classLoader);
        if (SPOOF_COUNTRY) hookTelephony(lpparam.classLoader);

        if (PKG_GOOD_LOCK.equals(lpparam.packageName)) {
            hookInitialCleanup(lpparam.classLoader);
        }
    }

    private void hookInitialCleanup(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(
                    Application.class,
                    "attach",
                    Context.class,
                    new XC_MethodHook() {
                        @Override
                        protected void beforeHookedMethod(MethodHookParam param) {
                            Context baseContext = (Context) param.args[0];
                            if (baseContext == null) return;

                            SharedPreferences statePrefs = baseContext.getSharedPreferences(
                                    PREF_FLAG_FILE, Context.MODE_PRIVATE);
                            boolean alreadyCleaned = statePrefs.getBoolean(KEY_INITIAL_CLEAN_DONE, false);

                            if (!alreadyCleaned) {
                                performOneTimeCleanup(baseContext);
                                SharedPreferences freshPrefs = baseContext.getSharedPreferences(
                                        PREF_FLAG_FILE, Context.MODE_PRIVATE);
                                freshPrefs.edit().putBoolean(KEY_INITIAL_CLEAN_DONE, true).commit();
                                XposedBridge.log("[A36GoodLockSpoofer] One-time Good Lock data cleanup completed.");
                            }
                        }
                    }
            );
        } catch (Throwable t) {
            XposedBridge.log("[A36GoodLockSpoofer] hookInitialCleanup error: " + t.getMessage());
        }
    }

    private void performOneTimeCleanup(Context context) {
        try {
            File dataDir = context.getDataDir();
            if (dataDir == null || !dataDir.exists()) return;

            String[] targetFolders = new String[]{
                    "shared_prefs",
                    "databases",
                    "cache",
                    "code_cache",
                    "files",
                    "no_backup"
            };

            for (String folderName : targetFolders) {
                File dir = new File(dataDir, folderName);
                if (dir.exists()) {
                    deleteRecursive(dir);
                }
            }
        } catch (Throwable t) {
            XposedBridge.log("[A36GoodLockSpoofer] performOneTimeCleanup error: " + t.getMessage());
        }
    }

    private void deleteRecursive(File fileOrDir) {
        if (fileOrDir.isDirectory()) {
            File[] children = fileOrDir.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        //noinspection ResultOfMethodCallIgnored
        fileOrDir.delete();
    }

    private void spoofBuildFields() {
        setStaticField(Build.class, "MODEL", TARGET_MODEL);
        setStaticField(Build.class, "DEVICE", TARGET_DEVICE);
        setStaticField(Build.class, "PRODUCT", TARGET_PRODUCT);
        setStaticField(Build.class, "BRAND", "samsung");
        setStaticField(Build.class, "MANUFACTURER", "samsung");
        setStaticField(Build.class, "FINGERPRINT", buildFingerprint());
    }

    // Fingerprint built from the REAL one (keeps the real Android version, e.g. 17),
    // swapping only the product/device/model parts to A36.
    private String buildFingerprint() {
        try {
            String real = Build.FINGERPRINT;
            if (real == null || real.isEmpty() || real.contains("a36xq")) return real == null ? TARGET_FINGERPRINT : real;
            String fp = real.replaceFirst("/[^/:]+/[^/:]+:", "/" + TARGET_PRODUCT + "/" + TARGET_DEVICE + ":")
                    .replace("A266B", "A366B");
            dlogOnce("FINGERPRINT " + real + " -> " + fp);
            return fp;
        } catch (Throwable t) {
            dlogOnce("buildFingerprint FAILED: " + t);
            return TARGET_FINGERPRINT;
        }
    }

    private static String why(Throwable t) {
        Throwable c = t;
        while (c.getCause() != null && c.getCause() != c) c = c.getCause();
        return c.getClass().getSimpleName() + ": " + c.getMessage();
    }

    // Android 17 forbids Field.set() on static final fields, so try several ways.
    private void setStaticField(Class<?> clazz, String fieldName, Object value) {
        Field field;
        try {
            field = clazz.getDeclaredField(fieldName);
            field.setAccessible(true);
        } catch (Throwable t) {
            dlogOnce("setStaticField " + fieldName + " no field: " + why(t));
            return;
        }
        if (isSet(field, value)) {
            dlogOnce("setStaticField " + fieldName + " already " + value);
            return;
        }

        // 1) plain reflection
        try {
            field.set(null, value);
        } catch (Throwable t) {
            dlogOnce("[1 reflection] " + fieldName + ": " + why(t));
        }
        if (isSet(field, value)) {
            dlogOnce("setStaticField " + fieldName + " OK (reflection)");
            return;
        }

        // 2) clear FINAL flag
        for (String flagField : new String[]{"accessFlags", "modifiers"}) {
            try {
                Field af = Field.class.getDeclaredField(flagField);
                af.setAccessible(true);
                af.setInt(field, field.getModifiers() & ~java.lang.reflect.Modifier.FINAL);
                field.set(null, value);
            } catch (Throwable t) {
                dlogOnce("[2 " + flagField + "] " + fieldName + ": " + why(t));
            }
            if (isSet(field, value)) {
                dlogOnce("setStaticField " + fieldName + " OK (" + flagField + ")");
                return;
            }
        }

        // 3) sun.misc.Unsafe (static base/offset first, then objectFieldOffset)
        try {
            Class<?> uc = Class.forName("sun.misc.Unsafe");
            Field uf = uc.getDeclaredField("theUnsafe");
            uf.setAccessible(true);
            Object unsafe = uf.get(null);
            Object base = clazz;
            long off;
            try {
                base = uc.getMethod("staticFieldBase", Field.class).invoke(unsafe, field);
                off = (Long) uc.getMethod("staticFieldOffset", Field.class).invoke(unsafe, field);
                dlogOnce("[3 unsafe] using staticFieldBase/Offset for " + fieldName);
            } catch (Throwable t) {
                dlogOnce("[3 unsafe static*] " + fieldName + ": " + why(t));
                off = (Long) uc.getMethod("objectFieldOffset", Field.class).invoke(unsafe, field);
            }
            uc.getMethod("putObject", Object.class, long.class, Object.class).invoke(unsafe, base, off, value);
        } catch (Throwable t) {
            dlogOnce("[3 unsafe] " + fieldName + ": " + why(t));
        }
        dlogOnce("setStaticField " + fieldName + (isSet(field, value) ? " OK (unsafe)" : " ALL METHODS FAILED"));
    }

    private boolean isSet(Field field, Object value) {
        try {
            return value.equals(field.get(null));
        } catch (Throwable t) {
            return false;
        }
    }

    private void hookSystemProperties(ClassLoader classLoader) {
        try {
            Class<?> sysProps = XposedHelpers.findClass("android.os.SystemProperties", classLoader);
            XposedBridge.hookAllMethods(sysProps, "get", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    handleGet(param);
                }
            });
            XC_MethodHook logOnly = new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args.length > 0 && param.args[0] instanceof String) {
                        String key = (String) param.args[0];
                        if (INTERESTING.matcher(key).find()) {
                            dlogOnce("SP." + param.method.getName() + " " + key + " = " + param.getResult());
                        }
                    }
                }
            };
            for (String n : new String[]{"getInt", "getLong", "getBoolean"}) {
                XposedBridge.hookAllMethods(sysProps, n, logOnly);
            }
            dlogOnce("SystemProperties hooks installed");
        } catch (Throwable t) {
            dlogOnce("hookSystemProperties FAILED: " + t);
        }

        try {
            Class<?> sem = XposedHelpers.findClassIfExists("com.samsung.android.os.SemSystemProperties", classLoader);
            if (sem == null) {
                dlogOnce("SemSystemProperties class NOT found");
            } else {
                XposedBridge.hookAllMethods(sem, "get", new XC_MethodHook() {
                    @Override
                    protected void afterHookedMethod(MethodHookParam param) {
                        handleGet(param);
                    }
                });
                dlogOnce("SemSystemProperties hooks installed");
            }
        } catch (Throwable t) {
            dlogOnce("SemSystemProperties hook FAILED: " + t);
        }
    }

    private void handleGet(XC_MethodHook.MethodHookParam param) {
        if (param.args.length == 0 || !(param.args[0] instanceof String)) return;
        String key = (String) param.args[0];
        String spoofed = mapProperty(key);
        Object real = param.getResult();
        if (spoofed != null) {
            param.setResult(spoofed);
            dlogOnce("SP " + key + ": " + real + " -> " + spoofed);
        } else if (INTERESTING.matcher(key).find()) {
            dlogOnce("SP(unmapped) " + key + " = " + real);
        }
    }

    private String mapProperty(String key) {
        if (key == null) return null;
        if (MODEL_KEYS.contains(key)) return TARGET_MODEL;
        if (DEVICE_KEYS.contains(key)) return TARGET_DEVICE;
        if (PRODUCT_KEYS.contains(key)) return TARGET_PRODUCT;
        if (SPOOF_CSC && CSC_KEYS.contains(key)) return TARGET_CSC;
        if (SPOOF_CSC && PRODUCT_CODE_KEYS.contains(key)) return TARGET_PRODUCT_CODE;
        if ("ro.build.characteristics".equals(key) || "ro.vendor.build.characteristics".equals(key)) {
            return "phone";
        }
        if (SPOOF_COUNTRY && "ro.csc.country_code".equals(key)) return "GERMANY";
        if (SPOOF_COUNTRY && "ro.csc.countryiso_code".equals(key)) return "DE";
        return null;
    }

    private void hookFloatingFeature(ClassLoader classLoader) {
        try {
            Class<?> semFF = XposedHelpers.findClassIfExists(
                    "com.samsung.android.feature.SemFloatingFeature", classLoader);
            if (semFF == null) {
                dlogOnce("SemFloatingFeature class NOT found");
                return;
            }
            XC_MethodHook h = new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    if (param.args.length == 0 || !(param.args[0] instanceof String)) return;
                    String tag = (String) param.args[0];
                    Object real = param.getResult();
                    if (param.method.getName().equals("getBoolean")
                            && (tag.contains("ONEUI_CORE") || tag.contains("SEP_LITE"))) {
                        param.setResult(false);
                        dlogOnce("FF " + tag + ": " + real + " -> false");
                    } else {
                        dlogOnce("FF(unmapped) " + param.method.getName() + " " + tag + " = " + real);
                    }
                }
            };
            for (String n : new String[]{"getBoolean", "getString", "getInt"}) {
                XposedBridge.hookAllMethods(semFF, n, h);
            }
            dlogOnce("SemFloatingFeature hooks installed");
        } catch (Throwable t) {
            dlogOnce("hookFloatingFeature FAILED: " + t);
        }
    }

    private void hookTelephony(ClassLoader classLoader) {
        try {
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getSimOperator", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("26201"); dlogOnce("TELEPHONY " + param.method.getName() + " -> 26201");
                }
            });
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getNetworkOperator", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("26201"); dlogOnce("TELEPHONY " + param.method.getName() + " -> 26201");
                }
            });
            XposedHelpers.findAndHookMethod(TelephonyManager.class, "getSimCountryIso", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    param.setResult("de"); dlogOnce("TELEPHONY getSimCountryIso -> de");
                }
            });
        } catch (Throwable t) {
            dlogOnce("hookTelephony FAILED: " + t);
        }
    }
}
