package com.spoofer.a36goodlock;

import android.os.Build;
import java.io.File;
import de.robv.android.xposed.XposedBridge;
import java.util.Arrays;
import java.util.List;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final List<String> TARGET_PACKAGES = Arrays.asList(
            "com.samsung.android.goodlock",
            "com.sec.android.app.samsungapps"
    );

    private static final String SPOOF_MODEL = "SM-A366B";
    private static final String SPOOF_DEVICE = "a36xq";
    private static final String SPOOF_PRODUCT = "a36xqxx";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) {
            return;
        }

        resetAppDataOnce(lpparam);

        XposedHelpers.setStaticObjectField(Build.class, "MODEL", SPOOF_MODEL);
        XposedHelpers.setStaticObjectField(Build.class, "DEVICE", SPOOF_DEVICE);
        XposedHelpers.setStaticObjectField(Build.class, "PRODUCT", SPOOF_PRODUCT);

        try {
            Class<?> sysProps = XposedHelpers.findClass("android.os.SystemProperties", lpparam.classLoader);
            XC_MethodHook propHook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length > 0 && param.args[0] instanceof String) {
                        String key = (String) param.args[0];
                        switch (key) {
                            case "ro.product.model":
                            case "ro.product.vendor.model":
                            case "ro.product.system.model":
                            case "ro.product.odm.model":
                            case "ro.product.product.model":
                                param.setResult(SPOOF_MODEL);
                                break;
                            case "ro.product.device":
                            case "ro.product.vendor.device":
                            case "ro.product.system.device":
                                param.setResult(SPOOF_DEVICE);
                                break;
                            case "ro.product.name":
                            case "ro.product.vendor.name":
                            case "ro.product.system.name":
                                param.setResult(SPOOF_PRODUCT);
                                break;
                        }
                    }
                }
            };

            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, propHook);
            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, String.class, propHook);
        } catch (Throwable ignored) {
        }
    }

    // Marker lives in the app data root, which is NOT wiped below.
    private static final String RESET_MARKER = ".spoofer_reset_done";
    private static final String[] WIPE_DIRS = {
            "shared_prefs", "databases", "cache", "code_cache", "files", "no_backup"
    };

    /**
     * Wipes the target app's local data exactly once (first launch with the hook active).
     * Galaxy Store: wiped on first launch after the module is enabled.
     * Good Lock: wiped on its first launch with the hook (i.e. right after it was installed).
     * Runs in handleLoadPackage, i.e. before the app opens its own files.
     */
    private void resetAppDataOnce(XC_LoadPackage.LoadPackageParam lpparam) {
        try {
            // only the main process, so side processes don't race each other
            if (lpparam.processName != null && !lpparam.processName.equals(lpparam.packageName)) {
                return;
            }
            if (lpparam.appInfo == null || lpparam.appInfo.dataDir == null) {
                return;
            }
            File dataDir = new File(lpparam.appInfo.dataDir);
            File marker = new File(dataDir, RESET_MARKER);
            if (marker.exists()) {
                return;
            }
            for (String name : WIPE_DIRS) {
                deleteRecursive(new File(dataDir, name));
            }
            marker.createNewFile();
            XposedBridge.log("A36Spoofer: first-run data reset done for " + lpparam.packageName);
        } catch (Throwable t) {
            XposedBridge.log("A36Spoofer: data reset failed for " + lpparam.packageName + ": " + t);
        }
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        File[] children = f.listFiles();
        if (children != null) {
            for (File c : children) deleteRecursive(c);
        }
        f.delete();
    }
}
