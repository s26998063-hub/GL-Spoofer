package com.spoofer.a36goodlock;

import android.os.Build;
import java.util.Arrays;
import java.util.List;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final List<String> TARGET_PACKAGES = Arrays.asList(
            "com.samsung.android.goodlock",
            "com.sec.android.app.samsungapps"
    );

    private static final String SPOOF_MODEL = "SM-A366B";
    private static final String SPOOF_DEVICE = "a36xq";
    private static final String SPOOF_PRODUCT = "a36xqxx";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        if (!TARGET_PACKAGES.contains(lpparam.packageName)) {
            return;
        }

        XposedHelpers.setStaticObjectField(Build.class, "MODEL", SPOOF_MODEL);
        XposedHelpers.setStaticObjectField(Build.class, "DEVICE", SPOOF_DEVICE);
        XposedHelpers.setStaticObjectField(Build.class, "PRODUCT", SPOOF_PRODUCT);

        try {
            Class<?> sysProps = XposedHelpers.findClass("android.os.SystemProperties", lpparam.classLoader);
            XC_MethodHook propHook = new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    if (param.args != null && param.args.length > 0 && param.args[0] instanceof String) {
                        String key = (String) param.args[0];
                        switch (key) {
                            case "ro.product.model":
                            case "ro.product.vendor.model":
                            case "ro.product.system.model":
                            case "ro.product.odm.model":
                            case "ro.product.product.model":
                                param.setResult(SPOOF_MODEL);
                                break;
                            case "ro.product.device":
                            case "ro.product.vendor.device":
                            case "ro.product.system.device":
                                param.setResult(SPOOF_DEVICE);
                                break;
                            case "ro.product.name":
                            case "ro.product.vendor.name":
                            case "ro.product.system.name":
                                param.setResult(SPOOF_PRODUCT);
                                break;
                        }
                    }
                }
            };

            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, propHook);
            XposedHelpers.findAndHookMethod(sysProps, "get", String.class, String.class, propHook);
        } catch (Throwable ignored) {
        }
    }
}
